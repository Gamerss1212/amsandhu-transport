# Your approvals

Your own decisions. When you switch real money on in the app (Real money box, step 2),
QuantAgents writes a dated row here with your name. Real money only runs while such a
row exists. Switching it off keeps the row as a record.

## Human approvals

| Date | Decision | Owner |
|---|---|---|
| (none yet) | | |
