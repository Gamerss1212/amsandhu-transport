"""Command line: `quantagents <command>` (or `python -m quantagents <command>`).

Run from the repo root. Everything is paper trading; no command can send a real order.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections.abc import Sequence
from datetime import UTC, date, datetime
from pathlib import Path

import numpy as np

from quantagents import __version__, daily, ops, watchdog
from quantagents.agents.a35_scorekeeper import Scorekeeper
from quantagents.agents.a45_stress import stress_returns
from quantagents.audit import AuditLog, read_records, verify_chain
from quantagents.backtest.engine import Backtester
from quantagents.backtest.event import EventBacktester, EventCosts
from quantagents.backtest.strategies import DEFAULT_VARIANT, buy_and_hold, strategy_grid
from quantagents.config import AppConfig, load_config
from quantagents.data import commands as data_commands
from quantagents.data.store import data_labels
from quantagents.data.synthetic import DEMO_AS_OF, synthetic_market
from quantagents.execution.paper import PaperAccount
from quantagents.lots import acb_report
from quantagents.market import MarketData, load_csv, periods_per_year, save_csv
from quantagents.orchestrator import Orchestrator
from quantagents.registry import Registry
from quantagents.report import (
    DISCLAIMER,
    format_backtest,
    format_cycle_report,
    format_event_backtest,
    format_registry,
    format_simulation,
    format_strategy_stress,
    format_validation,
)
from quantagents.research import format_report, run_research, write_variants_csv
from quantagents.risk.killswitch import RESET_PHRASE, KillSwitch
from quantagents.simulate import run_paper_simulation
from quantagents.validation.leakage import RedTeamAuditor
from quantagents.validation.stats import StatisticalValidator
from quantagents.validation.trials import (
    TRIALS_FILE,
    Trial,
    append_trials,
    data_id,
    trial_count,
)

STATE_DIR = Path("state")
RUNS_DIR = Path("runs")
ACCOUNT_FILE = STATE_DIR / "paper_account.json"
KILL_FILE = STATE_DIR / "kill_switch.json"
SCORES_FILE = STATE_DIR / "scorekeeper.json"


def _config(args: argparse.Namespace) -> AppConfig:
    path = Path(args.config) if args.config else Path("config/default.yaml")
    return load_config(path if path.exists() else None)


def _market(args: argparse.Namespace, cfg: AppConfig) -> MarketData:
    if getattr(args, "data", None):
        _data_note(args.data)
        return load_csv(args.data)
    return synthetic_market(seed=cfg.system.seed)


def _universe_note(cfg: AppConfig, market: MarketData) -> None:
    """Say so plainly when the config's universe leaves nothing in the file to trade."""
    wanted = set(cfg.universe.symbols)
    if wanted and not wanted & set(market.symbols):
        print(
            f"Note: none of this file's symbols ({', '.join(market.symbols[:8])}) are in "
            f"universe.symbols in the config ({', '.join(sorted(wanted)[:8])}), so nothing can "
            "trade. Put your symbols there, or use [] to trade every symbol in the file.\n"
        )


def _data_note(path: str) -> None:
    """Every result on real data carries its source's caveats (spec sections 58, 74)."""
    for label in data_labels(path):
        print(f"Data {Path(path).name}: {label}")
    print()


def cmd_demo(args: argparse.Namespace) -> int:
    cfg = _config(args)
    market = synthetic_market(seed=cfg.system.seed)
    as_of = date.fromisoformat(args.as_of)
    account = PaperAccount(cfg.system.capital, cfg.costs)
    audit_path = RUNS_DIR / f"demo-{as_of.isoformat()}" / "audit.jsonl" if args.save else None
    if audit_path is not None and audit_path.exists():
        audit_path.unlink()
    orchestrator = Orchestrator(
        cfg, Registry.load(), account, KillSwitch(), audit=AuditLog(audit_path)
    )
    report = orchestrator.run_cycle(market, as_of)
    print("Demo on SYNTHETIC data (fake symbols SYN_A..SYN_F) with a fresh 10,000 paper account.\n")
    print(format_cycle_report(report, currency=cfg.system.base_currency))
    if audit_path is not None:
        (audit_path.parent / "report.json").write_text(
            report.model_dump_json(indent=2), encoding="utf-8"
        )
        print(f"\nSaved the report and audit log to {audit_path.parent}")
    return 0


def cmd_cycle(args: argparse.Namespace) -> int:
    cfg = _config(args)
    _data_note(args.data)
    market = load_csv(args.data)
    _universe_note(cfg, market)
    as_of = date.fromisoformat(args.as_of) if args.as_of else market.dates[-1]
    state = Path(args.state)
    scores_path = state.with_name(SCORES_FILE.name)
    account = PaperAccount.load_or_new(state, cfg.system.capital, cfg.costs)
    held = {s for s, q in account.ledger.book.quantities().items() if q}
    missing = held - set(market.symbols)
    if missing:  # a position with no price would make the account value wrong
        raise ValueError(
            f"the paper account in {state} holds {', '.join(sorted(missing))}, which "
            f"{args.data} does not have. One folder holds one paper account: use a second "
            "copy of QuantAgents-50 for another universe."
        )
    scorekeeper = Scorekeeper.load_or_new(scores_path)
    orchestrator = Orchestrator(
        cfg,
        Registry.load(),
        account,
        KillSwitch(KILL_FILE),
        audit=AuditLog(RUNS_DIR / "audit.jsonl"),
        scorekeeper=scorekeeper,
        simulate_next_open=False,
    )
    report = orchestrator.run_cycle(market, as_of)
    account.save(state)
    scorekeeper.save(scores_path)
    out = RUNS_DIR / "cycles" / f"{report.cycle_id}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report.model_dump_json(indent=2), encoding="utf-8")
    print(format_cycle_report(report, currency=cfg.system.base_currency))
    print(f"\nSaved account state to {state}, A35 memory to {scores_path}, report to {out}")
    return 0


def cmd_simulate(args: argparse.Namespace) -> int:
    cfg = _config(args)
    market = _market(args, cfg)
    _universe_note(cfg, market)
    end = date.fromisoformat(args.end) if args.end else None
    sim = run_paper_simulation(cfg, Registry.load(), market, days=args.days, end=end)
    if not getattr(args, "data", None):
        print("SYNTHETIC data (fake symbols): this shows the machinery working, not an edge.\n")
    print(format_simulation(sim, currency=cfg.system.base_currency))
    return 0


def cmd_stress(args: argparse.Namespace) -> int:
    cfg = _config(args)
    market = _market(args, cfg)
    variants = dict(strategy_grid(args.strategy, cfg))
    name = args.variant or DEFAULT_VARIANT[args.strategy]
    if name not in variants:
        raise KeyError(f"unknown variant {name!r}; choose from {sorted(variants)}")
    base = Backtester(cfg.costs.one_way_cost).run(market, variants[name](market), name=name)
    doubled = Backtester(2 * cfg.costs.one_way_cost).run(market, variants[name](market), name=name)
    result = stress_returns(
        base.returns, ruin_drawdown=cfg.risk.max_drawdown_pct / 100.0, seed=cfg.system.seed
    )
    note = (
        f"2x cost stress: Sharpe {base.metrics['sharpe']:.2f} -> {doubled.metrics['sharpe']:.2f}, "
        f"total return {base.metrics['total_return']:+.1%} -> {doubled.metrics['total_return']:+.1%}"
    )
    print(format_backtest(base))
    print(format_strategy_stress(name, result, note))
    _log(
        args,
        cfg,
        [(name, "vectorized, 1x and 2x costs, A45 stress", base.metrics["sharpe"], "stress run")],
    )
    print(f"\n{DISCLAIMER}")
    return 0


def cmd_backtest(args: argparse.Namespace) -> int:
    cfg = _config(args)
    market = _market(args, cfg)
    variants = dict(strategy_grid(args.strategy, cfg))
    name = args.variant or DEFAULT_VARIANT[args.strategy]
    if name not in variants:
        raise KeyError(f"unknown variant {name!r}; choose from {sorted(variants)}")
    if args.engine == "event":
        event = EventBacktester(EventCosts.from_config(cfg), cfg.system.capital).run(
            market, variants[name](market), name=name
        )
        print(format_event_backtest(event, cfg.system.base_currency))
        detail, sharpe = "event-driven A43, config costs", event.metrics["sharpe"]
    else:
        result = Backtester(cfg.costs.one_way_cost).run(market, variants[name](market), name=name)
        print(format_backtest(result))
        detail, sharpe = (
            f"vectorized A43, {cfg.costs.one_way_cost:.2%} one way",
            result.metrics["sharpe"],
        )
    _log(args, cfg, [(name, detail, sharpe, "backtest only, not validated")])
    print(f"\n{DISCLAIMER}")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    cfg = _config(args)
    market = _market(args, cfg)
    grid = strategy_grid(args.strategy, cfg)
    chosen = args.variant or DEFAULT_VARIANT[args.strategy]
    engine = Backtester(cfg.costs.one_way_cost)
    results = {name: engine.run(market, factory(market), name=name) for name, factory in grid}
    if chosen not in results:
        raise KeyError(f"unknown variant {chosen!r}; choose from {sorted(results)}")
    stressed = Backtester(2 * cfg.costs.one_way_cost).run(
        market, dict(grid)[chosen](market), name=chosen
    )
    matrix = np.column_stack([r.returns for r in results.values()])
    real = bool(getattr(args, "data", None))
    names = list(results)
    n_trials = trial_count(args.strategy, names) if real else len(grid)
    notes = [
        f"{len(grid)} variant(s) run now; {n_trials} trial(s) charged to this family "
        "(every variant ever run on real data counts)."
    ]
    if not real:
        notes.append("Synthetic data: a PASS or FAIL here proves nothing about real markets.")
    market_returns = Backtester(0.0).run(market, buy_and_hold()(market), name="market").returns
    report = StatisticalValidator(cfg.validation).validate(
        results[chosen].returns,
        strategy=chosen,
        n_trials=n_trials,
        trial_matrix=matrix,
        stressed_returns=stressed.returns,
        notes=notes,
        seed=cfg.system.seed,
        trial_names=names,
        market_returns=market_returns,
        periods_per_year=periods_per_year(market.dates),
    )
    red_team = RedTeamAuditor(max_gross=cfg.risk.max_gross_exposure_pct / 100.0).audit(
        dict(grid)[chosen], market, name=chosen
    )
    print(format_backtest(results[chosen]))
    print(format_validation(report, red_team))
    verdict = "PASS" if report.passed and red_team.passed else "FAIL"
    _log(
        args,
        cfg,
        [
            (
                name,
                f"validate, vectorized, {cfg.costs.one_way_cost:.2%} one way",
                result.metrics["sharpe"],
                f"{verdict} (A44 + A39, reported variant)"
                if name == chosen
                else "variant (counted)",
            )
            for name, result in results.items()
        ],
    )
    print(f"\n{DISCLAIMER}")
    return 0


def _log(args: argparse.Namespace, cfg: AppConfig, rows: list[tuple[str, str, float, str]]) -> None:
    """Spec section 63: every run is a trial, written to docs/research/trials.md."""
    data = data_id(getattr(args, "data", None), cfg.system.seed)
    today = datetime.now(UTC).date()
    append_trials(
        [
            Trial(today, args.strategy, name, detail, data, sharpe, verdict)
            for name, detail, sharpe, verdict in rows
        ]
    )
    print(f"\nLogged {len(rows)} trial(s) to {TRIALS_FILE}.")


def cmd_agents(args: argparse.Namespace) -> int:
    print(format_registry(Registry.load(), args.phase, core_only=args.core))
    return 0


def cmd_killswitch(args: argparse.Namespace) -> int:
    switch = KillSwitch(KILL_FILE)
    if args.action == "engage":
        state = switch.engage(args.reason or "manual stop", by="human")
        print(f"Kill switch ENGAGED: {state.reason}")
    elif args.action == "reset":
        switch.reset(args.confirm or "", by="human")
        print("Kill switch reset. Trading may resume on the next cycle.")
    else:
        state = switch.state()
        print(
            f"Kill switch {'ENGAGED' if state.engaged else 'armed (not engaged)'}"
            + (f": {state.reason} (by {state.by} at {state.at_utc})" if state.engaged else "")
        )
        if state.engaged:
            print(f"To reset after review: quantagents killswitch reset --confirm {RESET_PHRASE}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    cfg = _config(args)
    lines = ops.status_report(
        cfg,
        config_path=args.config or "config/default.yaml",
        state_file=Path(args.state),
        kill_file=KILL_FILE,
        runs_dir=RUNS_DIR,
        data=Path(args.data) if args.data else None,
        today=datetime.now(UTC).date(),
    )
    print("\n".join(lines))
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    report = ops.doctor(config_path=args.config)
    print("\n".join(report.lines()))
    return 1 if report.errors else 0


def cmd_watchdog(args: argparse.Namespace) -> int:
    report = watchdog.run(
        runs_dir=RUNS_DIR,
        state_file=Path(args.state),
        kill_file=KILL_FILE,
        data=Path(args.data) if args.data else None,
        max_missed_days=args.max_missed_days,
        max_data_age_days=args.max_data_age_days,
        engage=not args.dry_run,
    )
    if report.ok:
        print("Watchdog: all clear.")
        return 0
    for problem in report.problems:
        print(f"Watchdog: {problem}")
    if report.engaged:
        print(
            f"Kill switch ENGAGED. After review: quantagents killswitch reset --confirm {RESET_PHRASE}"
        )
    return 1


def _free_path(name: str) -> Path:
    """``name``, or ``name`` with -2, -3... added: a research record is never overwritten."""
    path = Path(name)
    k = 2
    while path.exists() or path.with_suffix(".csv").exists():
        path = Path(name).with_name(f"{Path(name).stem}-{k}{Path(name).suffix}")
        k += 1
    return path


def cmd_research(args: argparse.Namespace) -> int:
    cfg = _config(args)
    universes: dict[str, str] = {}
    for spec in args.universe:
        name, _, path = spec.partition("=")
        if not name or not path:
            raise ValueError(f"write each universe as NAME=CSV, not {spec!r}")
        if not Path(path).exists():
            raise FileNotFoundError(path)
        universes[name] = path
    today = datetime.now(UTC).date()
    report = run_research(
        universes,
        cfg=cfg,
        noise=args.noise,
        jobs=max(1, args.jobs),
        families=args.families,
        run_date=today,
        trials_path=TRIALS_FILE,
    )
    out = Path(args.report) if args.report else _free_path(f"docs/research/grid-{today}.md")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(format_report(report), encoding="utf-8")
    write_variants_csv(report, out.with_suffix(".csv"))
    for u in report.universes:
        verdict = "n/a" if u.finalist is None else ("PASS" if u.finalist.passed else "FAIL")
        print(
            f"{u.name}: best {u.best} Sharpe {u.get(u.best).sharpe:.2f} vs buy-and-hold "
            f"{u.benchmark.sharpe:.2f}; finalist {verdict}"
        )
    print(f"\n{report.backtests:,} backtests. Report: {out} (+ {out.with_suffix('.csv').name})")
    print(f"Logged {report.real_trials} trial(s) to {TRIALS_FILE}.")
    print(f"\n{DISCLAIMER}")
    return 0


def cmd_config(args: argparse.Namespace) -> int:
    cfg = _config(args)
    s, r = cfg.system, cfg.risk
    print("Config is valid.")
    print(
        f"Phase {s.phase} | mode {s.execution_mode.value} | autonomy {s.autonomy_level} | capital {s.capital:,.0f} {s.base_currency}"
    )
    print(
        f"Risk per trade {r.max_risk_per_trade_pct}% (major at {r.major_trade_risk_pct}%) | daily {r.max_daily_loss_pct}% | weekly {r.max_weekly_loss_pct}% | drawdown {r.max_drawdown_pct}%"
    )
    print(
        f"Leverage {'on' if r.leverage_allowed else 'off'} | shorting {'on' if r.shorting_allowed else 'off'} | universe {', '.join(cfg.universe.symbols)}"
    )
    return 0


def cmd_make_data(args: argparse.Namespace) -> int:
    cfg = _config(args)
    save_csv(synthetic_market(seed=cfg.system.seed), args.out)
    print(f"Wrote synthetic prices to {args.out} (fake symbols, for testing only)")
    return 0


def cmd_audit(args: argparse.Namespace) -> int:
    ok, message = verify_chain(read_records(Path(args.path)))
    print(("OK: " if ok else "TAMPERED: ") + message)
    return 0 if ok else 1


def cmd_acb(args: argparse.Namespace) -> int:
    cfg = _config(args)
    account = PaperAccount.load_or_new(Path(args.state), cfg.system.capital, cfg.costs)
    print(json.dumps(acb_report(account.ledger.fills).model_dump(mode="json"), indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="quantagents", description="QuantAgents-50 starter kit (paper trading only)."
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--config", help="config YAML (default: config/default.yaml)")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("demo", help="run one decision cycle on synthetic data")
    p.add_argument("--as-of", default=DEMO_AS_OF.isoformat())
    p.add_argument("--save", action="store_true", help="save the report and audit log under runs/")
    p.set_defaults(func=cmd_demo)

    p = sub.add_parser("cycle", help="run one paper-trading cycle on your CSV data")
    p.add_argument("--data", required=True, help="CSV: date,symbol,open,high,low,close,volume")
    p.add_argument("--as-of", help="defaults to the last date in the file")
    p.add_argument("--state", default=str(ACCOUNT_FILE))
    p.set_defaults(func=cmd_cycle)

    p = sub.add_parser("simulate", help="run the full cycle day by day on a fresh paper account")
    p.add_argument("--days", type=int, default=120, help="trading days to simulate")
    p.add_argument("--end", help="last decision date (default: the second-to-last date)")
    p.add_argument("--data", help="CSV data (default: synthetic)")
    p.set_defaults(func=cmd_simulate)

    for name, func, text in (
        ("backtest", cmd_backtest, "backtest a strategy (A43)"),
        (
            "validate",
            cmd_validate,
            "backtest every variant, then run A44 statistics and the A39 red team",
        ),
        ("stress", cmd_stress, "A45 Monte Carlo and 2x-cost stress of a strategy"),
    ):
        p = sub.add_parser(name, help=text)
        p.add_argument("--strategy", default="tsmom", choices=sorted(DEFAULT_VARIANT))
        p.add_argument("--variant", help="one named variant (default: the family's preset)")
        p.add_argument("--data", help="CSV data (default: synthetic)")
        if name == "backtest":
            p.add_argument(
                "--engine",
                choices=["vector", "event"],
                default="vector",
                help="vector: fast screening; event: orders, partial fills, impact, ADV cap",
            )
        p.set_defaults(func=func)

    p = sub.add_parser("agents", help="list the agent roster (25 core + 25 parked)")
    p.add_argument("--phase", type=int, help="only agents switched on by this phase")
    p.add_argument("--core", action="store_true", help="only the 25-agent core")
    p.set_defaults(func=cmd_agents)

    p = sub.add_parser("killswitch", help="status, engage or reset the kill switch")
    p.add_argument("action", choices=["status", "engage", "reset"])
    p.add_argument("--reason")
    p.add_argument("--confirm", help=f"type {RESET_PHRASE} to reset")
    p.set_defaults(func=cmd_killswitch)

    p = sub.add_parser(
        "research", help="the pre-registered grid: every variant, every universe, noise controls"
    )
    p.add_argument("--universe", action="append", required=True, metavar="NAME=CSV")
    p.add_argument("--noise", type=int, default=20, help="noise-control panels per universe")
    p.add_argument("--jobs", type=int, default=os.cpu_count() or 1, help="parallel processes")
    p.add_argument("--families", nargs="+", help="only these families (quick checks only)")
    p.add_argument("--report", help="markdown report path (a .csv is written next to it)")
    p.set_defaults(func=cmd_research)

    p = sub.add_parser(
        "status", help="one-screen dashboard: account, kill switch, cycles, watchdog"
    )
    p.add_argument("--state", default=str(ACCOUNT_FILE))
    p.add_argument("--data", help="the CSV the daily cycle reads (checks how fresh it is)")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("doctor", help="check the install, config and folders (reads only)")
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("watchdog", help="stop trading if cycles or data go stale (never resets)")
    p.add_argument(
        "--data", help="the CSV the daily cycle reads (checks how old its newest bar is)"
    )
    p.add_argument("--state", default=str(ACCOUNT_FILE))
    p.add_argument("--max-missed-days", type=int, default=2, help="weekdays without a cycle")
    p.add_argument("--max-data-age-days", type=int, default=3, help="weekdays since the newest bar")
    p.add_argument("--dry-run", action="store_true", help="report only; do not engage the switch")
    p.set_defaults(func=cmd_watchdog)

    p = sub.add_parser("config", help="validate the config and print a summary")
    p.set_defaults(func=cmd_config)

    p = sub.add_parser("make-data", help="write synthetic prices to a CSV")
    p.add_argument("--out", default="data/synthetic.csv")
    p.set_defaults(func=cmd_make_data)

    p = sub.add_parser("audit", help="verify the audit log hash chain")
    p.add_argument("--path", default=str(RUNS_DIR / "audit.jsonl"))
    p.set_defaults(func=cmd_audit)

    data_commands.add_parser(sub)
    daily.add_parser(sub)

    p = sub.add_parser("acb", help="adjusted cost base report from paper fills (not tax advice)")
    p.add_argument("--state", default=str(ACCOUNT_FILE))
    p.set_defaults(func=cmd_acb)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:  # never crash on a character the console cannot show
            reconfigure(errors="replace")
    args = build_parser().parse_args(argv)
    try:
        result: int = args.func(args)
    except (ValueError, KeyError, LookupError, FileNotFoundError, PermissionError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return result
