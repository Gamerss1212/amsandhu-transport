# QuantAgents-50

Read START_HERE.md, then double-click QuantAgents.bat (Windows) or run bash QuantAgents.sh (macOS/Linux).
